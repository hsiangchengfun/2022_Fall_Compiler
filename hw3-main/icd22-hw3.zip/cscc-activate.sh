dosh run plaslab/compiler-f20-hw3:latest /bin/bash
