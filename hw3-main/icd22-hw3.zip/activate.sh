docker run --rm -it -w /root -v "${PWD}":/root/hw3 plaslab/compiler-f20-hw3:latest /bin/bash
