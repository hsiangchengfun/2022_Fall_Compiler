yes | /bin/MobaBox.exe apt-get install make
yes | /bin/MobaBox.exe apt-get install flex
yes | /bin/MobaBox.exe apt-get install gcc-core
yes | /bin/MobaBox.exe apt-get install m4
yes | /bin/MobaBox.exe apt-get install zip
yes | /bin/MobaBox.exe apt-get install bison
yes | /bin/MobaBox.exe apt-get install guile
